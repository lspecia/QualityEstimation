#!/bin/bash
java -classpath lib/MTFeatures.jar:lib/commons-cli-1.2.jar FeatureExtractor -lang english spanish -input input/source.eng input/target_system.spa -mode bb -config config_enes.properties
